const http = require('http');
const fs = require('fs');
const path = require('path');

// Lambda handler export (for AWS Lambda)
exports.handler = async (event, context) => {
  console.log('=== REQUEST EVENT ===');
  console.log('Method:', event.httpMethod);
  console.log('Path:', event.path || event.rawPath);
  console.log('Body:', event.body);
  console.log('==================');

  // Lazy load only the middleware up front; route modules are loaded on demand.
  const cors = require('./middleware/cors');

  const clientDir = path.join(__dirname, '..', 'client');

  const contentTypes = {
    '.html': 'text/html; charset=utf-8',
    '.css': 'text/css; charset=utf-8',
    '.js': 'application/javascript; charset=utf-8',
    '.json': 'application/json; charset=utf-8',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.svg': 'image/svg+xml'
  };

  function sendFile(res, filePath) {
    try {
      const data = fs.readFileSync(filePath);
      const ext = path.extname(filePath).toLowerCase();
      res.writeHead(200, { 'Content-Type': contentTypes[ext] || 'application/octet-stream' });
      res.end(data);
    } catch (error) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Not found');
    }
  }

  function serveStatic(req, res) {
    let requestPath = req.url === '/' ? '/index.html' : req.url;
    requestPath = requestPath.split('?')[0];

    if (requestPath === '/admin') {
      requestPath = '/admin.html';
    } else if (requestPath === '/parking') {
      requestPath = '/parking.html';
    } else if (requestPath === '/incidents') {
      requestPath = '/incidents.html';
    } else if (requestPath === '/shift-logs') {
      requestPath = '/shift-logs.html';
    } else if (requestPath === '/print') {
      requestPath = '/print.html';
    }

    const safePath = path.normalize(requestPath).replace(/^(\.|\/)+/, '');
    const filePath = path.join(clientDir, safePath);

    if (!filePath.startsWith(clientDir)) {
      res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Forbidden');
      return;
    }

    if (!fs.existsSync(filePath)) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Not found');
      return;
    }

    sendFile(res, filePath);
  }

  return new Promise((resolve, reject) => {
    // Parse body from API Gateway event
    let bodyData = {};
    try {
      if (event.body) {
        bodyData = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
      }
    } catch (e) {
      // Body parse error will be handled by routes
    }

    const mockReq = {
      method: event.httpMethod || 'GET',
      url: event.path || event.rawPath || event.requestContext?.path || '/',
      headers: event.headers || {},
      body: bodyData,
      // Support stream-like interface for routes that use parseBody
      listeners: {},
      on: function(event, callback) {
        if (event === 'data') {
          // Immediately call callback with stringified body
          callback(JSON.stringify(this.body));
        } else if (event === 'end') {
          // Call end callback immediately
          callback();
        }
        return this;
      }
    };

    const mockRes = {
      statusCode: 200,
      headers: {},
      body: '',
      setHeader: function(key, value) {
        this.headers[key] = value;
      },
      writeHead: function(code, headers) {
        this.statusCode = code;
        if (headers) Object.assign(this.headers, headers);
      },
      end: function(data) {
        this.body = data || '';
        resolve({
          statusCode: this.statusCode,
          headers: this.headers,
          body: this.body,
          isBase64Encoded: false
        });
      }
    };

    cors(mockReq, mockRes, () => {
      if (!mockReq.url.startsWith('/api/')) {
        serveStatic(mockReq, mockRes);
        return;
      }

      const pathname = mockReq.url.split('?')[0];
      const method = mockReq.method;
      const { handleAuthRoutes } = require('./routes/authRoutes');

      const authHandled = handleAuthRoutes(mockReq, mockRes, pathname, method);
      if (authHandled === true) return;

      const parkingRoutes = require('./routes/parkingRoutes');
      const parkingHandled = parkingRoutes(mockReq, mockRes);
      if (parkingHandled !== null) return;

      const incidentRoutes = require('./routes/incidentRoutes');
      const incidentHandled = incidentRoutes(mockReq, mockRes);
      if (incidentHandled !== null) return;

      const shiftLogRoutes = require('./routes/shiftLogRoutes');
      const shiftLogHandled = shiftLogRoutes(mockReq, mockRes);
      if (shiftLogHandled !== null) return;

      const notificationRoutes = require('./routes/notificationRoutes');
      const notificationHandled = notificationRoutes(mockReq, mockRes);
      if (notificationHandled !== null) return;

      const dashboardRoutes = require('./routes/dashboardRoutes');
      const dashboardHandled = dashboardRoutes(mockReq, mockRes);
      if (dashboardHandled !== null) return;

      const adminRoutes = require('./routes/adminRoutes');
      const adminHandled = adminRoutes(mockReq, mockRes);
      if (adminHandled !== null) return;

      mockRes.writeHead(404, { 'Content-Type': 'application/json' });
      mockRes.end(JSON.stringify({ error: 'Route not found' }));
    });
  });
};

// Local development server (only runs when executed directly with node, not in Lambda)
if (require.main === module) {
  const port = process.env.PORT || 3000;
  const cors = require('./middleware/cors');
  const parkingRoutes = require('./routes/parkingRoutes');
  const incidentRoutes = require('./routes/incidentRoutes');
  const shiftLogRoutes = require('./routes/shiftLogRoutes');
  const notificationRoutes = require('./routes/notificationRoutes');
  const dashboardRoutes = require('./routes/dashboardRoutes');
  const adminRoutes = require('./routes/adminRoutes');
  const { handleAuthRoutes } = require('./routes/authRoutes');

  const clientDir = path.join(__dirname, '..', 'client');

  const contentTypes = {
    '.html': 'text/html; charset=utf-8',
    '.css': 'text/css; charset=utf-8',
    '.js': 'application/javascript; charset=utf-8',
    '.json': 'application/json; charset=utf-8',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.svg': 'image/svg+xml'
  };

  function sendFile(res, filePath) {
    fs.readFile(filePath, (error, data) => {
      if (error) {
        res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end('Not found');
        return;
      }

      const ext = path.extname(filePath).toLowerCase();
      res.writeHead(200, { 'Content-Type': contentTypes[ext] || 'application/octet-stream' });
      res.end(data);
    });
  }

  function serveStatic(req, res) {
    let requestPath = req.url === '/' ? '/index.html' : req.url;
    requestPath = requestPath.split('?')[0];

    if (requestPath === '/admin') {
      requestPath = '/admin.html';
    } else if (requestPath === '/parking') {
      requestPath = '/parking.html';
    } else if (requestPath === '/incidents') {
      requestPath = '/incidents.html';
    } else if (requestPath === '/shift-logs') {
      requestPath = '/shift-logs.html';
    } else if (requestPath === '/print') {
      requestPath = '/print.html';
    }

    const safePath = path.normalize(requestPath).replace(/^(\.|\/)+/, '');
    const filePath = path.join(clientDir, safePath);

    if (!filePath.startsWith(clientDir)) {
      res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Forbidden');
      return;
    }

    if (!fs.existsSync(filePath)) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Not found');
      return;
    }

    sendFile(res, filePath);
  }

  const server = http.createServer((req, res) => {
    cors(req, res, () => {
      if (req.url.startsWith('/api/')) {
        const pathname = req.url.split('?')[0];
        const method = req.method;
        
        const authHandled = handleAuthRoutes(req, res, pathname, method);
        if (authHandled === true) {
          return;
        }

        const parkingHandled = parkingRoutes(req, res);
        if (parkingHandled !== null) {
          return;
        }

        const incidentHandled = incidentRoutes(req, res);
        if (incidentHandled !== null) {
          return;
        }

        const shiftLogHandled = shiftLogRoutes(req, res);
        if (shiftLogHandled !== null) {
          return;
        }

        const notificationHandled = notificationRoutes(req, res);
        if (notificationHandled !== null) {
          return;
        }

        const dashboardHandled = dashboardRoutes(req, res);
        if (dashboardHandled !== null) {
          return;
        }

        const adminHandled = adminRoutes(req, res);
        if (adminHandled !== null) {
          return;
        }

        res.writeHead(404, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Route not found' }));
        return;
      }

      serveStatic(req, res);
    });
  });

  server.listen(port, () => {
    console.log(`Parking management website is running on http://localhost:${port}`);
  });
}
